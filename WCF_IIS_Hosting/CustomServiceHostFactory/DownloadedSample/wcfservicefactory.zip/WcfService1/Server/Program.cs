﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using WcfService1;
using System.ServiceModel.Channels;
using System.ServiceModel;

namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            IList<Type> services = new List<Type> { typeof(WcfService1.Service1), typeof(WcfService1.Service2) };
            List<WebServiceHost> hosts = new List<WebServiceHost>();

            int port = 5000;

            foreach (Type serviceType in services)
            {
                Uri baseAddress = new Uri("http://localhost:" + port.ToString());
                port++;

                WebServiceHost serviceHost = new WebServiceHost(serviceType, baseAddress);
                serviceHost.AddServiceEndpoint(serviceType.GetInterfaces()[0], new BasicHttpBinding() { Name = serviceType.Name }, baseAddress); 
                
                hosts.Add(serviceHost);
                serviceHost.Open();
            }

            Console.WriteLine("Servidor on. Pressione uma tecla para fechar.");
            Console.ReadKey();

            foreach (WebServiceHost serviceHost in hosts)
            {
                serviceHost.Close();
            }

            hosts.Clear();
            services.Clear();
        }
    }
}
