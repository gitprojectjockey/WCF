﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyModule
{
    class MyHandler : System.Web.IHttpHandler
    {
        #region IHttpHandler Members

        public bool IsReusable
        {
            get { throw new NotImplementedException(); }
        }

        public void ProcessRequest(System.Web.HttpContext context)
        {
            //
        }

        #endregion
    }
}
