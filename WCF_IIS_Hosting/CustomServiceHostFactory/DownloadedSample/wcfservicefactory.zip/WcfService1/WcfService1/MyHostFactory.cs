﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Activation;
using System.ServiceModel;

namespace WcfService1
{
    public class MyHostFactory : ServiceHostFactory
    {
        protected override ServiceHost CreateServiceHost(Type serviceType, Uri[] baseAddresses)
        {
            ServiceHost host = new ServiceHost(serviceType, baseAddresses);

            foreach (Uri address in baseAddresses)
            {
                WSHttpBinding b = new WSHttpBinding(SecurityMode.Message);
                b.Name = serviceType.Name;
                host.AddServiceEndpoint(serviceType.GetInterfaces()[0], b, address);
            }

            return host;
        }
    }
}
