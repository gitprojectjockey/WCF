﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Client.ServiceReference1;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            //consume();
            consumeWithChannelFactory();

            Console.WriteLine();
            Console.WriteLine("Press <ENTER> to terminate client.");
            Console.ReadLine();
        }

        static void consume()
        {
            ServiceReference1.Service1Client client = new Client.ServiceReference1.Service1Client();

            ServiceReference2.Service2Client client2 = new Client.ServiceReference2.Service2Client();

            string result = client.GetData(1);
            Console.WriteLine(result);

            Console.ReadKey();

            result = client2.GetData2(2);
            Console.WriteLine(result);

            //Closing the client gracefully closes the connection and cleans up resources
            client.Close();
        }

        static void consumeWithChannelFactory()
        {
            WSHttpBinding myBinding = new WSHttpBinding();

            EndpointAddress myEndpoint = new EndpointAddress("http://localhost:3578/Service1.svc");

            ChannelFactory<IService1> myChannelFactory = new ChannelFactory<IService1>(myBinding, myEndpoint);

            // Create a channel.
            IService1 wcfClient1 = myChannelFactory.CreateChannel();
            string result = wcfClient1.GetData(11);
            Console.WriteLine(result);
        }
    }
}
